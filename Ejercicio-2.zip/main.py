lista = []
print('Ingrese 10 numeros: ')
for x  in range (10):
  numero = int(input())
  lista.append(numero)
num_peque = min(lista)
posicion = lista.index(num_peque)

print(f'El numero menor es:{num_peque}, y se encuentra en la posicion: {posicion+1}')