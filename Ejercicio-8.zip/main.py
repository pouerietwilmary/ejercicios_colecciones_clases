alt5perosnas = []
prome = 0
altumayor = 0
altumenor = 0

for x in range(5):
  alturas = float(input(F'Digite la estatura de la persona numero {x+1}: \n '))
  prome+alturas
  alt5perosnas.append(alturas)
for x in range (5):
  if (alt5perosnas[x] > prome/5):
    altumayor +=1
altumenor = 5 - altumayor

print (f"Hay una cantidad de {altumayor} personas con una altura mayor al promedio, y hay una cantidad de {altumenor} de personas por debajo del promedio.")
