enero = 31
febrero = 28
marzo = 31
abril = 30
mayo = 31
junio = 30
julio = 31
agosto = 31
septiembre = 30
octubre = 31
noviembre = 30
diciembre = 31

mes = [enero ,febrero,marzo,abril,mayo,junio,julio,agosto,septiembre,octubre,noviembre,diciembre]

def volver ():
  meses_ano()
def meses_ano():
  print('1-Enero.')
  print('2-Febreo.')
  print('3-Marzo.')
  print('4-Abril.')
  print('5-Mayo.')
  print('6-Junio.')
  print('7-Julio.')
  print('8-Agosto.')
  print('9-Septiembre')
  print('10-Octubre')
  print('11-Noviembre')
  print('12-Diciembre')
  lista = int(input('Ingrese un numero:'))
  if lista == 1:
    print(f"Enero tiene {mes[0]} dias")
  elif lista == 2: 
    print(f'Febrero tiene {mes[1]} dias')
  elif lista == 3: 
    print(f'Marzo tiene {mes[2]} dias')
  elif lista == 4: 
    print(f'Abril tiene {mes[3]} dias')
  elif lista == 5: 
    print(f'Mayo tiene {mes[4]} dias')
  elif lista == 6: 
    print(f'Junio tiene {mes[5]} dias')
  elif lista == 7: 
    print(f'Julio tiene {mes[6]} dias')
  elif lista == 8: 
    print(f'Agosto tiene {mes[7]} dias')
  elif lista == 9:
    print(f'Septiembre tiene {mes[8]} dias')
  elif lista == 10: 
    print(f'Octubre tiene {mes[9]} dias')
  elif lista == 11: 
    print(f'Novimebre tiene {mes[10]} dias')
  elif lista == 12: 
    print(f'Diciembre tiene {mes[11]} dias') 
    volver()
  else: 
    print('Este mes no existe.') 
volver()