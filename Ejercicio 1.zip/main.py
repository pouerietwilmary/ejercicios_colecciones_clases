memoria = []

for x in range (4):
  numero = int(input('Ingrese un numero:'))
  memoria.append(numero)
  
total = len(memoria)
suma = sum(memoria)
prom = (suma/total)

print(memoria)
print(prom)