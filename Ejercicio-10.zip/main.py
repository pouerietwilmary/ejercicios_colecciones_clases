lista = []
for x in range(5):
  edad=int(input('Ingrese las edades:')) 
  if edad >= 18:
    lista.append(edad)
print(f'Las edades adultas son: {lista}')