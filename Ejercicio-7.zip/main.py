lista = []
for x in range(0,20):
  num = int(input('Introuzca un numero: '))
  lista.append(num)
  if num % 2 == 0:
    lista.remove(num)

print(f"Numeros impares:{lista}")