def c():
    a=int
    b=int
    a=input("Ingresa un numero: ")
    b=input("Ingrese otro numero: ")
    if a<b:
        print(b," Es el mayor.")
    else:
        print(a," Es el mayor.")
    pass
c()