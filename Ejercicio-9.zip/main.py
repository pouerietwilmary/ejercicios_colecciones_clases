valor=int(input('Ingrese un numero mayor que 0:'))

while valor > 0:
  tabla = int(input('Ingrese un numero para ver su tabla:\n'))
  if tabla == -1:
    print('Fin.')
    break
  else:
    for t in range(1,13):
      print(f'{t} x {tabla} = {t * tabla}')