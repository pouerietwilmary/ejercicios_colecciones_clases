lista = []
sueldo = []
for x in range (2):
  persona = nombre = (input("Ingrese tu nombre:")); monto= float(input("Digite su sueldo:"))
  lista.append(persona)
  sueldo.append(monto*3)

sumax = max(sueldo)
print(lista)
print(sueldo)
print (sumax)