principal_lista = []
lista1=[]
lista2=[]
lista3=[]

for x in range (5):
  elemento1 = int(input(f'Ingrese su numero {x+1} para que se agregue a la lista 1:'))
  lista1.append(elemento1)
for x in range(5):
  elemento2=int(input(f'Ingrese su numero {x+1} para que se agregue a la lista 2: '))
  lista2.append(elemento2)
for x in range(5):
  elemento3 = int(input(f'Ingrese su numero {x+1} para que se agregue a la lista 3: '))
  lista3.append(elemento3)

suma1=sum(lista1)
suma2=sum(lista2)
suma3=sum(lista3)
principal_lista.append(suma1)
principal_lista.append(suma2)
principal_lista.append(suma3)
total = principal_lista
print(f'\nLa suma de cada lista es: {total}.\n')